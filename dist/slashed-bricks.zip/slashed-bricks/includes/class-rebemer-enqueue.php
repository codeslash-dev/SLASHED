<?php
/**
 * Enqueue the reBEMer editor bundle inside the Bricks builder panel.
 *
 * Builder-only, capability-gated, stable filenames + filemtime cache-bust.
 *
 * @package SLASHED_Bricks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Slashed_Bricks_ReBEMer_Enqueue {

	const SCRIPT_HANDLE = 'slashed-bricks-rebemer';
	const STYLE_HANDLE  = 'slashed-bricks-rebemer';
	const ASSET_DIR     = 'assets/editor-app/';

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 9999 );
		add_filter( 'script_loader_tag', array( $this, 'mark_as_module' ), 10, 3 );
	}

	public function enqueue() {
		if ( ! function_exists( 'bricks_is_builder_main' ) || ! bricks_is_builder_main() ) {
			return;
		}
		if ( ! current_user_can( 'bricks_full_access' ) && ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$base_path = SLASHED_BRICKS_PATH . self::ASSET_DIR;
		$base_url  = SLASHED_BRICKS_URL . self::ASSET_DIR;

		$js_path = $base_path . 'app.js';
		if ( ! file_exists( $js_path ) ) {
			return; // Bundle not built yet.
		}

		$js_ver  = (string) filemtime( $js_path );
		$css_ver = file_exists( $base_path . 'app.css' ) ? (string) filemtime( $base_path . 'app.css' ) : $js_ver;

		wp_enqueue_style( self::STYLE_HANDLE, $base_url . 'app.css', array(), $css_ver );
		wp_enqueue_script( self::SCRIPT_HANDLE, $base_url . 'app.js', array(), $js_ver, true );

		$plugin_settings = Slashed_Bricks_Token_Store::get_plugin_settings();
		wp_localize_script(
			self::SCRIPT_HANDLE,
			'slashedBricksEditor',
			array(
				'showClassHints' => ! empty( $plugin_settings['show_class_hints'] ),
				'classHints'     => Slashed_Bricks_Admin_Page_Svelte::get_class_hints(),
			)
		);
	}

	public function mark_as_module( $tag, $handle, $src ) {
		if ( self::SCRIPT_HANDLE !== $handle ) {
			return $tag;
		}
		// Strip any existing type attribute to avoid duplicates on WP < 6.3.
		$tag = preg_replace( '/\stype=["\'][^"\']*["\']/', '', $tag, 1 );
		return str_replace( '<script ', '<script type="module" ', $tag );
	}
}
